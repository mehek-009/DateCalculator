package com.example.datecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText day,year;
TextView date,lp_yr,week;
Button check;
Boolean leap=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        day=findViewById(R.id.day);
        year=findViewById(R.id.year);
        date=findViewById(R.id.date);
        week=findViewById(R.id.week);
        lp_yr=findViewById(R.id.lp_yr);
        check=findViewById(R.id.check);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(day.getText().toString().isEmpty()||year.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter day and year", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int arr[]={31,28,31,30,31,30,31,31,30,31,30,31};
                    int i=0;
                    int dy=Integer.parseInt(day.getText().toString());
                    int yr=Integer.parseInt(year.getText().toString());
                    int wk=dy/7;
                    if(yr%400==0||(yr%4==0&&yr%100!=0))
                        leap=true;
                    if(leap)
                    {
                        arr[1] = 29;
                    }
                    while(dy>0)
                    {
                        dy=dy-arr[i];
                        i++;
                    }
                    dy=dy+arr[i-1];
                    String st=dy+"-"+i+"-"+yr;
                    date.setText(st);
                    week.setText(String.valueOf(wk));
                    lp_yr.setText(String.valueOf(leap));
                }
            }
        });
    }
}